#! /bin/bash

time java -server -Xmx1G -jar ./follower-maze-2.0.jar
